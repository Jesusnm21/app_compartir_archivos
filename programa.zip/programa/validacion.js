const FRMCALCULA = document.querySelector("#frmCalcula");
FLRCALCULA.addEventListener("file", uploadFile);

function uploadFile() {
    var fileInput = document.getElementById('fileInput');
    var file = fileInput.files[0];
    var ipInput = document.getElementById('ipInput');
    var ipAddress = ipInput.value; // Obtener la dirección IP ingresada por el usuario

    // Verificar si se seleccionó un archivo
    if (!file) {
      alert('Por favor, selecciona un archivo');
      return;
    }

    // Verificar si se ingresó una dirección IP
    if (ipAddress.trim() === '') {
      alert('Por favor, ingresa una dirección IP');
      return;
    }

    var formData = new FormData();
    formData.append('file', file);

    // Realizar la solicitud POST al servidor con la dirección IP proporcionada
    fetch('http://' + ipAddress + ':3000/upload', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
  }