const express = require('express');
const fileUpload = require('express-fileupload');
const app = express();
const PORT = 3000;

app.use(fileUpload());

app.post('/upload', (req, res) => {
  const uploadedFile = req.files.file;
  uploadedFile.mv('uploads/' + uploadedFile.name, (err) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.send('Archivo subido correctamente!');
  });
});

app.listen(PORT, () => {
  console.log('Servidor escuchando en el puerto ${PORT}');
});
